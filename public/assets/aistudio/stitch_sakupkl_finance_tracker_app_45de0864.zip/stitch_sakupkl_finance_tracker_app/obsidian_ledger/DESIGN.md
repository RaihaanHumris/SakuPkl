---
name: Obsidian Ledger
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#ffb2b7'
  on-secondary: '#67001b'
  secondary-container: '#b50036'
  on-secondary-container: '#ffc2c4'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#ffdadb'
  secondary-fixed-dim: '#ffb2b7'
  on-secondary-fixed: '#40000d'
  on-secondary-fixed-variant: '#92002a'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system projects precision, financial autonomy, and focused clarity tailored for interns managing daily allowances, stipends, and project-related expenditures. 

The aesthetic synthesizes modern corporate refinement with high-contrast tactical utility. It leverages deep obsidian and slate foundations punctuated by surgical emerald, rose, and amber accents. The interface avoids frivolous ornamentation in favor of purposeful information density, razor-sharp contrast, and tactile state feedback. The resulting product feels like a disciplined executive instrument stripped down for rapid, single-handed, day-to-day logging.

## Colors

The palette operates strictly within a curated dark-spectrum hierarchy to prevent eye fatigue while ensuring instant metric decipherability:

- **Canvas & Backgrounds:**
  - Base canvas: `#0B0F19` (Deep void canvas)
  - Secondary/Sidebar base: `#0F172A` (Rich slate)
- **Surfaces & Containers:**
  - Default card/surface: `#1E293B`
  - Elevated floating surfaces/menus: `#334155`
  - Subtle interactive states: Hover tokens add `rgba(255, 255, 255, 0.04)` over surface tones.
- **Accents & Semantics:**
  - **Emerald (`#10B981`):** Primary interactions, savings goals, income, positive balances, and primary confirmations.
  - **Rose (`#F43F5E`):** Daily expense outputs, critical threshold breaches, and deletion actions.
  - **Amber (`#F59E0B`):** Budget warnings, remaining limit alerts, and pending reimbursements.
- **Text & Contrast:**
  - High-emphasis titles & numbers: `#F8FAFC`
  - Medium-emphasis body & primary metadata: `#E2E8F0`
  - Low-emphasis helper text, category timestamps: `#94A3B8`
- **Boundaries & Dividers:**
  - Default structural borders: `rgba(255, 255, 255, 0.08)` or solid `#334155` where hardware rendering requires flat fallbacks.

## Typography

Plus Jakarta Sans governs the entire typographic stack, delivering geometric structure alongside human readability.

- **Monetary Figures & Big Data Displays:** Quantitative metrics in `display-lg` and `headline-lg` must always use tabular figures (`font-variant-numeric: tabular-nums`) to prevent horizontal jitter during real-time balance calculations.
- **Hierarchy Rules:**
  - High-impact currency amounts pair heavy weights (700/800) with tight letter-spacing.
  - Form field inputs and dynamic spending amounts utilize `title-md` or `headline-sm` for immediate recognition.
  - Micro-tags, category indicators, and timestamps use `label-sm` with slight positive tracking and uppercase transformation.

## Layout & Spacing

The layout adapts a compact 8pt base grid tailored for continuous data scanning and fast touch entry:

- **Mobile (<768px):** Single-column layout anchored by a sticky bottom navigation or floating entry trigger. Margins remain locked at `1rem` to maximize usable screen real estate for ledger records.
- **Tablet (768px–1023px):** Two-column fluid grid. Left pane holds daily balance overviews and budget progress; right pane handles line-item transaction feeds.
- **Desktop (≥1024px):** Fixed-fluid hybrid system with a persistent 260px navigation sidebar, a central 680px transaction stream, and an auxiliary 340px summary/analytics rail.

Internal component gaps follow strict tokens: `space-xs` (4px) for inline metadata, `space-sm` (8px) for related form elements or chip clusters, `space-md` (16px) for internal card padding, and `space-xl` (32px) for canvas section separators.

## Elevation & Depth

Visual hierarchy does not rely on heavy drop shadows, which muddy dark interfaces. Depth is achieved via tonal surfacing paired with razor-thin structural borders:

- **Base Layer (Level 0):** Canvas `#0B0F19` with no borders.
- **Surface Layer (Level 1):** Cards and list clusters use `#1E293B` surrounded by a `1px` border of `rgba(255, 255, 255, 0.08)`.
- **Raised Interactive Layer (Level 2):** Dropdowns, quick-add transaction modals, and active sheets sit on `#334155` with an ambient glow shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.12)`.
- **Accent Glows:** Primary action elements and critical budget alerts introduce an optical colored halo on focus/hover (e.g., `box-shadow: 0 0 16px rgba(16, 185, 129, 0.2)`).

## Shapes

The design system maintains a refined, modern curvature using the `roundedness: 2` scale (0.5rem base):

- **Standard Elements (0.5rem / 8px):** Checkboxes, text inputs, transaction row items, and primary buttons.
- **Structural Containers (1rem / 16px):** Metric cards, bottom sheets, and modal wrappers.
- **Pill Elements (Full Round):** Category badges (e.g., "Lunch", "Commute"), status indicators, and micro filter chips.

## Components

- **Buttons:**
  - *Primary (Affirmative/Add):* Solid `#10B981` background, `#0B0F19` bold typography. On hover: shifts brightness up with emerald ambient glow.
  - *Destructive (Expense Log/Delete):* Solid `#F43F5E` background or `#1E293B` container with `#F43F5E` text and border.
  - *Secondary / Ghost:* Transparent with `#334155` border and `#F8FAFC` label; background becomes `rgba(255, 255, 255, 0.05)` on hover.
- **Input Fields & Currency Inputs:**
  - Base background of `#0F172A` with a `1px` border of `#334155`.
  - Placeholder text in `#94A3B8`.
  - Focus state: Border shifts to `#10B981` accompanied by a `2px` focus ring `rgba(16, 185, 129, 0.25)`.
  - Prefix/Suffix elements (e.g., currency symbols "Rp", "$") maintain fixed width and `#94A3B8` styling.
- **Cards & Summary Tiles:**
  - Solid `#1E293B` background with `1px` border of `rgba(255, 255, 255, 0.08)`.
  - Key balance cards embed an inner accent bar (3px width) running along the left border (Emerald for surplus, Rose for daily overspend).
- **Transaction Lists:**
  - Row-based items separated by `1px` divider (`rgba(255, 255, 255, 0.04)`).
  - Left slot: Circular icon container `#0F172A` with category icon.
  - Center slot: Title in `title-md` (`#F8FAFC`) with timestamp/subtext in `body-sm` (`#94A3B8`).
  - Right slot: Tabular numeric currency amount (Green with `+` for reimbursements/allowances, White or Rose with `-` for expenses).
- **Chips & Tags:**
  - Height: 28px. Full pill radius.
  - Inactive state: `#0F172A` background with `rgba(255,255,255,0.08)` border.
  - Active state: `#10B981` background at 15% opacity, text in `#10B981`, border in `#10B981`.
- **Progress Bars (Daily Budget Tracking):**
  - Track: `#0F172A`, 6px height, fully rounded.
  - Indicator: Single-fill bar dynamically shifting from `#10B981` (under 75% daily cap) to `#F59E0B` (75%–95%) to `#F43F5E` (>95% or breached).