---
name: Pocket Intern Utility
colors:
  surface: '#FFFFFF'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#3d4a42'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#6d7a72'
  outline-variant: '#bccac0'
  surface-tint: '#006c4a'
  primary: '#006948'
  on-primary: '#ffffff'
  primary-container: '#00855d'
  on-primary-container: '#f5fff7'
  inverse-primary: '#68dba9'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#4d5d73'
  on-tertiary: '#ffffff'
  tertiary-container: '#66768d'
  on-tertiary-container: '#fdfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#85f8c4'
  primary-fixed-dim: '#68dba9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  expense-rose: '#E11D48'
  expense-rose-light: '#FFE4E6'
  income-emerald: '#059669'
  income-emerald-light: '#D1FAE5'
  warning-amber: '#F59E0B'
  warning-amber-light: '#FEF3C7'
  border-subtle: '#E2E8F0'
  border-strong: '#CBD5E1'
  text-muted: '#94A3B8'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  currency-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  currency-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
  currency-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.25rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

The design system is crafted specifically for vocational high school (SMK) and university students undergoing internship programs (Praktik Kerja Lapangan / PKL). At this formative life stage, users face strict daily pocket-money constraints, high emotional friction when facing unexpected micro-expenses (commute parking, lunch warteg, photocopy costs), and zero tolerance for convoluted financial interfaces. 

The aesthetic is **Crisp Functional Minimalism** with high contrast and tactile, thumb-friendly utility. The visual hierarchy strips away banking jargon and decorative clutter, delivering an immediate, glanceable sense of financial control. The emotional tone balances professional trust with supportive clarity: never judgmental when budgets run thin, but unmistakably clear about daily thresholds. 

Key design attributes:
- **Instant Glanceability:** Primary numerical values (safe limits, remaining balance) are legible from arm's length or in glaring midday sunlight.
- **Frictionless Velocity:** Micro-interactions favor quick taps, sticky bottom sheets, and preset chips over multi-step wizards or dense text inputs.
- **Strict Semantic Weight:** Green signifies safe, controlled surplus; Amber signals approaching threshold limits; Rose denotes active burn rate or over-budget states.

## Colors

The color architecture is built around clear light-mode legibility, utilizing `#F8FAFC` (Slate 50) as an eye-relieving backdrop that makes pure white (`#FFFFFF`) card surfaces sit forward with distinct boundary clarity. 

Color assignments follow strict semantic intent:
- **Primary (`#059669` - Emerald 600):** Anchors constructive actions, positive cash flow, safe progress balance, and dominant calls to action. Accompanied by `#D1FAE5` for soft pill indicators.
- **Secondary (`#0F172A` - Slate 900):** Provides maximum contrast for monetary figures, titles, and structural icons. It grounds the UI in solid, crisp typography.
- **Tertiary (`#64748B` - Slate 500):** Supports secondary metrics, date groupings, metadata notes, and inactive state cues.
- **Expense / Alert (`#E11D48` - Rose 600):** Delivers critical signals for expenses, overspent categories, and warnings. Paired with `#FFE4E6` for light-tinted backgrounds.
- **Warning / Limit (`#F59E0B` - Amber 500):** Activated dynamically when daily spending crosses $\ge 80\%$ of the calculated daily threshold.

Avoid using pure `#000000` blacks or decorative gradients. All interactive states rely on defined shifts between these tokens, ensuring accessibility standard compliance (minimum 4.5:1 contrast against `#FFFFFF` or `#F8FAFC`).

## Typography

The typographic hierarchy pairs **Plus Jakarta Sans** for prominent headers, numbers, and hero card displays with **Inter** for data readability, body copy, and system labels.

Crucial implementation rules:
- **Tabular Figures:** Any context showing currency figures (Indonesian Rupiah `Rp`), numerical counters, dates, or progress percentages must declare `font-variant-numeric: tabular-nums`. This prevents misalignment along vertical lists and ensures quick visual scanning down expense entries.
- **Rupiah Formatting:** Always position currency tokens (`Rp`) with a non-breaking space followed by period-delimited thousands (e.g., `Rp 15.000`).
- **Letter Spacing:** Headlines utilize subtle negative tracking (`-0.01em` to `-0.03em`) to keep monetary blocks tight and punchy. Labels and meta-tags apply positive tracking (`0.01em` to `0.04em`) with uppercase transforms where appropriate to balance micro-footprints.

## Layout & Spacing

The design system uses a centered, mobile-first single-column shell constrained to `max-w-md` (`448px`) across all screen types. On tablets and desktop screens, this container remains centered horizontally on the canvas with auto-margins, simulating a focused smartphone experience while maintaining ergonomics.

### Layout Mechanics
- **Device Shell Constraints:** Max canvas width of `28rem` (`448px`). Outer margins on mobile phones default to `1rem` (`16px`), expanding to `1.25rem` (`20px`) on viewports $\ge 640\text{px}$.
- **Vertical Spacing Cadence:** Vertical gaps between discrete content blocks (Hero card, quick-preset row, grouped transactions) maintain a consistent `1.25rem` rhythm.
- **Thumb-Zone Prioritization:** All primary inputs and triggers reside within the lower $40\%$ of the screen. The primary action (`+ Catat Transaksi`) is sticky-docked above the bottom safe area (`padding-bottom: env(safe-area-inset-bottom, 1rem)`).
- **Horizontal Preset Carousel:** Quick-preset chips employ single-row horizontal overflows (`overflow-x: auto`) with negative horizontal margin bleeds and momentum scrolling for single-thumb flick selection.

## Elevation & Depth

Visual hierarchy avoids heavy drop shadows, instead using **ambient structural containment** and **low-contrast outline separation** tailored for high ambient-light visibility.

Depth is handled through four purposeful layers:
1. **Canvas Layer (`Level 0`):** `#F8FAFC`. Base surface underlying all structures.
2. **Surface Container (`Level 1`):** `#FFFFFF` paired with an ultra-light border (`1px solid #E2E8F0`) and an ambient micro-shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`. Applied to transaction items, filter chips, and card shells.
3. **Hero Budget Card (`Level 2`):** `#FFFFFF` with elevated ambient definition: `0 4px 6px -1px rgba(15, 23, 42, 0.05), 0 2px 4px -2px rgba(15, 23, 42, 0.03)` and a border `1px solid #E2E8F0`.
4. **Bottom Sheet & Sticky Floating Actions (`Level 3`):** `#FFFFFF` with structural elevation: `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.06)` combined with a darkened backdrop blur overlay (`rgba(15, 23, 42, 0.4)` with `backdrop-filter: blur(4px)`).

Zero colored or tinted drop shadows are permitted; depth is reinforced through contrast edges and clean surface shifts.

## Shapes

The shape system adopts a deliberate scale: structural cards use generous curvature, while interactive components remain slightly tighter for visual cohesion:
- **Card Containers & Modal Headers:** Standardized at `16px` (`rounded-2xl` or `1rem`), providing a friendly, tactile boundary for content sections.
- **Buttons, Text Inputs, and Quick Preset Chips:** Fixed at `12px` (`rounded-xl` or `0.75rem`) to ensure comfortable tap targets without visual distortion.
- **Filter Tags & Semantic Badges:** Formed with full circular pills (`rounded-full` / `9999px`) to immediately communicate status or toggles distinct from rectangular inputs.
- **Progress Bars:** Fully pill-shaped track and fill (`rounded-full`) with an internal height of `8px` for smooth metric reading.

## Components

### 1. Buttons
- **Primary CTA (`+ Catat Transaksi`):** High-prominence block button. Background `#059669`, text `#FFFFFF`, height `52px`, `rounded-xl` (`12px`), font weight 600. Active tap feedback via `scale(0.98)` transform and `#047857` active fill.
- **Secondary / Ghost Button:** Transparent background, text `#0F172A`, border `1px solid #CBD5E1`. Used for reports, CSV exports, or modal dismissals.
- **Icon Utility Button:** Square `40x40px`, `rounded-xl`, neutral background `#FFFFFF`, border `1px solid #E2E8F0`, supporting icon size `20px` in `#64748B`.

### 2. Preset Chips (Quick-Add Row)
- Horizontal swipe container with zero scrollbar visible.
- Pill buttons: Background `#FFFFFF`, border `1px solid #E2E8F0`, padding `8px 14px`, `rounded-xl`.
- Layout: Emoji/Icon followed by label and price tag in `currency-sm` (e.g., `🍛 Makan Siang (15rb)`). Tap immediately populates form values.

### 3. Hero Budget Card
- Surface: `#FFFFFF`, border `1px solid #E2E8F0`, border-radius `16px`, padding `20px`.
- Balance Display: Label `Sisa Uang Saku` in `#64748B` (`body-sm`), balance value in `display-hero-mobile` (`#0F172A`).
- Dynamic Linear Gauge: Background track `#F1F5F9`, height `8px`, `rounded-full`. Indicator fill dynamically maps:
  - Green (`#059669`) for $> 30\%$ remaining.
  - Amber (`#F59E0B`) for $15\% - 30\%$ remaining.
  - Rose (`#E11D48`) for $< 15\%$ remaining.
- Dynamic Safe Daily Limit Footer: Sub-card container inside the hero. Background `#F8FAFC`, padding `10px 14px`, `rounded-lg`. Displays `Batas Aman Hari Ini: Rp XX.XXX`. Shifts to `#FEF3C7` (Amber) when daily spending crosses $80\%$ threshold, and `#FFE4E6` (Rose) when exceeded.

### 4. Transaction List Items
- Container: Single-line row inside grouped date cards, padding `12px 14px`, border-bottom `1px solid #F1F5F9` (last child borderless).
- Left: Category icon inside a `36x36px` container (`rounded-lg`, background `#F8FAFC`).
- Center: Transaction name in `#0F172A` (`headline-sm`) with category/note metadata underneath in `#64748B` (`body-sm`).
- Right: Formatted currency value aligned right. Expenses display `-Rp XX.XXX` in `#0F172A` (or `#E11D48` if flagged over-budget), Income displays `+Rp XX.XXX` in `#059669`. Uses `currency-md` with `tabular-nums`.

### 5. Input Fields & Quick-Add Bottom Sheet
- Input Mount: `48px` standard height, `rounded-xl`, border `1.5px solid #E2E8F0`, background `#FFFFFF`. Active focus changes border to `#059669` without box-shadow ring bleed.
- Giant Currency Input (Bottom Sheet): Large unbordered numeral field, `currency-lg` (`28px`), centered or leading-left `Rp` prefix in `#94A3B8`. Auto-focuses on open and formats commas/periods on input.
- Category Grid Selector: $5$-column single-tap icon matrix (`44x44px` touch targets) with label beneath, avoiding dropdown navigation.

### 6. Badges & Progress Limits
- Height `24px`, padding `0 10px`, `rounded-full`, typography `label-sm`.
- Safe state: Background `#D1FAE5`, text `#059669`.
- Warning state: Background `#FEF3C7`, text `#D97706`.
- Overlimit state: Background `#FFE4E6`, text `#E11D48`.